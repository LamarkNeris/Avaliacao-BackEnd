package com.dh.Catalog.dto;

import lombok.Data;

@Data
public class CatalogDto {

    private Long id;
    private String name;


}
